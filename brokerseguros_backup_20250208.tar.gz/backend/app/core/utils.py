"""
Funciones generales que pueden ser utilizadas
en diferentes partes de la aplicación
"""
