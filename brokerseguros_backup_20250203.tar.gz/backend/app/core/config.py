"""
Maneja la configuracion de variables de entorno, 
como credenciales de base de datos
claves secretas, etc.
"""
