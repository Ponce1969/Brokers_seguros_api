"""
Maneja las operaciones CRUD (Create, Read, Update, Delete) 
de la tabla de clientes en la base de datos.
"""