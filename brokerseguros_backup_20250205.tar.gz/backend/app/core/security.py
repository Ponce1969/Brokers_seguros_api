"""
Contiene funciones relacionadas con la autenticación y seguridad,
como el hash de contraseñas y la verificación de tokens JWT.
"""